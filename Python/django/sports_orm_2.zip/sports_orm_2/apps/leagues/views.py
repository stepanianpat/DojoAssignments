from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q, Count
from . import team_maker

def index(request):
	context = {
		"teamASC": Team.objects.filter(league__name="Atlantic Soccer Conference"),
		"penguinPlayers": Player.objects.filter(curr_team__team_name="Penguins"),
		"icbcPlayers": Player.objects.filter(curr_team__league__name="International Collegiate Baseball Conference"),
		"acafLopez": Player.objects.filter(curr_team__league__name="American Conference of Amateur Football", last_name="Lopez"),
		"footballPlayers": Player.objects.filter(curr_team__league__sport="Football"),
		"teamSophia": Team.objects.filter(curr_players__first_name="Sophia"),
		"leagueSophia": League.objects.filter(teams__curr_players__first_name="Sophia"),
		"playerFlores": Player.objects.filter(last_name="Flores").exclude(curr_team__team_name="Roughriders"),
		"teamSammy": Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans",),
		"playerManitoba": Player.objects.filter(all_teams__location="Manitoba"),
		"playerVikings": Player.objects.filter(all_teams__team_name="Vikings").exclude(curr_team__team_name="Vikings"),
		"jacobGray": Team.objects.exclude(team_name="Colts").filter(all_players__last_name="Gray", all_players__first_name="Jacob"),
		"joshuaBaseball": Player.objects.filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players", first_name="Joshua"),
		"teamsTwelve": Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gte=12),
		"playerSorted": Player.objects.annotate(num_teams=Count('all_teams')).order_by('num_teams')
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
