from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Course

def index(request):
    context = {
        "courses": Course.objects.all()
    }
    return render(request, "coursesApp/index.html", context)

def process(request):
    if len(request.POST['name']) < 1:
        messages.add_message(request, messages.WARNING, "Name cannot be blank.")
        return redirect('/')

    if len(request.POST['description']) > 141:
        messages.add_message(request, messages.WARNING, "Comment cannot exceed 140 characters.")
        return redirect('/')

    Course.objects.create(name=request.POST['name'],description=request.POST['description'])

    return redirect('/')

def remove(request, num):
    context = {
    "courseId": Course.objects.filter(id=num)
    }
    return render(request, "coursesApp/remove.html", context)

def goback(request):
    return redirect('/')

def delete(request, num):
    Course.objects.filter(id=num).delete()
    return redirect('/')
